<?php
/*
Plugin Name: Robist Social Icons
Description: This plugin shows your social icons of your website. This is the effort of Robist Group and developed by Shaon Majumder. And this is the second plugin of Robist. So, support us by using this theme.
For any information and feature update , email us at wordpressthemes@robist.com.

*/
/* Start Adding Functions Below this Line */


// Register and load the widget
function robist_socialicon_load_widget() {
    register_widget( 'robist_socialicon_widget' );
}
add_action( 'widgets_init', 'robist_socialicon_load_widget' );
 
// Creating the widget 
class robist_socialicon_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			// Base ID of your widget
			'robist_socialicon_widget', 

			// Widget name will appear in UI
			__('Robist Social Icons', 'robist_socialicon_widget_domain'), 

			// Widget description
			array( 'description' => __( 'Social Icons for your website', 'robist_socialicon_widget_domain' ), ) 
		);
	}

	
	
	
	// Creating widget front-end
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );

		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title'];

		// This is where you run the code and display the output
		echo __( '-', 'robist_socialicon_widget_domain' );
		echo $this->social_icon();
		
		echo $args['after_widget'];
		
	}

	
	//actions
	public function social_icon(){
	?>
		<div class="social-wrap">
			<?php $social_twitter = get_theme_mod('social_twitter');
				if (!empty($social_twitter)) { ?>
					<a href="<?php echo esc_url($social_twitter); ?>" target="_blank">
						<i class="fab fa-twitter-square" aria-hidden="true"></i>
					</a>
			<?php } ?>
			<?php $social_facebook = get_theme_mod('social_facebook');
				if (!empty($social_facebook)) { ?>
					<a href="<?php echo esc_url($social_facebook); ?>" target="_blank">
						<i class="fab fa-facebook-square" aria-hidden="true"></i>
					</a>
			<?php } ?>
			<?php $social_google = get_theme_mod('social_google');
				if (!empty($social_google)) { ?>
					<a href="<?php echo esc_url($social_google); ?>" target="_blank">
						<i class="fa fa-google-plus" aria-hidden="true"></i>
					</a>
			<?php } ?>

			<?php $social_instagram = get_theme_mod('social_instagram');
				if (!empty($social_instagram)) { ?>
					<a href="<?php echo esc_url($social_instagram); ?>" target="_blank">
						<i class="fa fa-instagram" aria-hidden="true"></i>
					</a>
			<?php } ?>
			<?php $social_pinterest = get_theme_mod('social_pinterest');
				if (!empty($social_pinterest)) { ?>
					<a href="<?php echo esc_url($social_pinterest); ?>" target="_blank">
						<i class="fa fa-pinterest" aria-hidden="true"></i>
					</a>
			<?php } ?>
			<?php $social_vimeo = get_theme_mod('social_vimeo');
				if (!empty($social_vimeo)) { ?>
					<a href="<?php echo esc_url($social_vimeo); ?>" target="_blank">
						<i class="fa fa-vimeo" aria-hidden="true"></i>
					</a>
			<?php } ?>
			<?php $social_youtube = get_theme_mod('social_youtube');
				if (!empty($social_youtube)) { ?>
					<a href="<?php echo esc_url($social_youtube); ?>" target="_blank">
						<i class="fab fa-youtube" aria-hidden="true"></i>
					</a>
			<?php } ?>
			<?php $social_linkedin = get_theme_mod('social_linkedin');
				if (!empty($social_linkedin)) { ?>
					<a href="<?php echo esc_url($social_linkedin); ?>" target="_blank">
						<i class="fa fa-linkedin" aria-hidden="true"></i>
					</a>
			<?php } ?>
		</div>
	<?php
	}
	//actions


	
	// Widget Backend 
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
		}
		else {
			$title = __( 'New title', 'robist_socialicon_widget_domain' );
		}
		// Widget admin form
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php 
	}

	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
} // Class robist_socialicon_widget ends here
/* Stop Adding Functions Below this Line */
?>